import java.io.BufferedReader;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class EchoMultiServer {
    private ServerSocket serverSocket;
    private static int currentPrice = 100;

    public void start(int port) throws IOException {
        serverSocket = new ServerSocket(port);
        System.out.println("SERVER STARTED ON PORT [" + port + "].");
        System.out.println("_____________");

        while (true) {
            new EchoClientHandler(serverSocket.accept(), this).start();
            // "this" is EchoMultiServer. start() is where multi-thread occurs
        }
    }

    public synchronized String getPrice() { // sync
        return "Current price: " + currentPrice;
    }

    public synchronized String placeBid(int newPrice) { // sync
        if (newPrice > currentPrice) {
            currentPrice = newPrice;
            return "[BID_SUCCESSFUL]: New highest price is " + currentPrice + " by a handsome person!";
        }
        else if (newPrice <= 0) return "ARE YOU STUPID?";
        return "[BID_REJECTED]: Price must be higher than " + currentPrice + "!";
    }

    private static void closeQuietly(AutoCloseable resource) {
        if (resource != null) {
            try {
                resource.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void stop() { closeQuietly(serverSocket); }

    // subclass of Thread
    private static class EchoClientHandler extends Thread {
        private final EchoMultiServer server;
        private final Socket clientSocket;
        private PrintWriter out;
        private BufferedReader in;

        public EchoClientHandler(Socket clientSocket, EchoMultiServer serverSocket) {
            this.clientSocket = clientSocket;
            this.server = serverSocket;
        }

        @Override
        public void run() {
            try {
                out = new PrintWriter(clientSocket.getOutputStream(), true);
                in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

                out.println("[PRICE] INITIAL PRICE SET: " + currentPrice);
                // this is the FIRST line ever to be sent to Client's interface

                String lineInput;
                while ((lineInput = in.readLine()) != null) {
                    if (".".equals(lineInput.trim())) {
                        out.println("See you later handsome boi!");
                        break;
                    }
                    try {
                        int amount = Integer.parseInt(lineInput.trim());
                        System.out.println("Someone handsome bid: " + amount);
                        out.println(server.placeBid(amount));
                    } catch (NumberFormatException e) {
                        out.println("[ERROR]: input a NUMBER.");
                    }
                }
            } catch (IOException e) {
                    e.printStackTrace();
            } finally {
                closeQuietly(in);
                closeQuietly(out);
                closeQuietly(clientSocket);
            }
        }
    }

    public static void main(String[] args) {
        EchoMultiServer server = new EchoMultiServer();
        try {
            server.start(8000);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            server.stop();
        }
    }
}