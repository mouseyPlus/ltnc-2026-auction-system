import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class EchoMultiClient {
    public static void main(String[] args) {
        String ip = "127.0.0.1";
        final int HOST = 8000;

        try {
            Socket clientSocket = new Socket(ip, HOST);
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            Scanner scanner = new Scanner(System.in);

            System.out.println("Successfully connected to " + ip + ":" + HOST);

            // welcome hello hi message or smth
            System.out.println("=====================");
            System.out.println("Welcome to our Auction Program! Glad to see such a wonderful person like you!");
            System.out.println("Insert numbers for price. Press '.' to quit bidding.");
            System.out.println("=====================");

            String initialPrice = in.readLine();
            if (initialPrice != null) {
                System.out.println("Server: " + initialPrice);
            }

            while (true) {
                System.out.print(">> Quick! Set a price >> ");
                String message = scanner.nextLine(); // input

                out.println(message);                // Send to Server
                String response = in.readLine();     // Receive from Server

                if (response != null) {
                    System.out.println("Server: " + response); // Actual response from Server
                }

                if (".".equals(message.trim())) {   // quit bidding
                    break;
                }
            }
        } catch (IOException e) {
            System.out.println("[Server]: Cannot connect or Disconnected.");
            e.printStackTrace();
        }
    }
}