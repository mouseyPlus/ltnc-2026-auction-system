interface CanFly { void fly(); }
interface CanSwim { void swim(); }
interface CanFight { void fight(); }

public class ActionCharacter {
    public void fight() { System.out.println("Hero is fighting..."); }
}

class Hero extends ActionCharacter implements CanFly, CanSwim, CanFight {
    public void fight() { System.out.println("Hero is fighting...");}
    public void fly() { System.out.println("Hero is flying."); }
    public void swim() { System.out.println("Hero is swimming."); }
}