public class Main {
    public static void main(String[] args) {
        Hero hero = new Hero();

        ((CanSwim) hero).swim();
        ((CanFight) hero).fight();
        ((CanFly) hero).fly();
    }
}