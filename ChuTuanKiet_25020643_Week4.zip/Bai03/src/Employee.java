interface IWorkable { void work(); }

abstract class Employee implements IWorkable {
    private String id, name;
    private double baseSalary;

    public Employee(String id, String name, double baseSalary) {
        this.id = id;
        this.name = name;
        this.baseSalary = baseSalary;
    }

//    public String getId() { return id; }
    public String getName() { return name; }
    public double getBaseSalary() { return baseSalary; }

    public abstract double calculatePay();
}

class OfficeWorker extends Employee {
    public OfficeWorker(String id, String name, double baseSalary) {
        super(id, name, baseSalary);
    }

    @Override
    public double calculatePay() {
        return getBaseSalary();
    }

    public void work() { System.out.println("Soạn thảo văn bản"); }
}

class Technician extends Employee {
    private double overtimeHours;

    public Technician(String id, String name, double baseSalary, double overtimeHours) {
        super(id, name, baseSalary);
        this.overtimeHours = overtimeHours;
    }

    public double getOvertimeHours() { return overtimeHours; }

    @Override
    public double calculatePay() {
        return getBaseSalary() + getOvertimeHours() * 20000;
    }

    public void work() { System.out.println("Lắp đặt thiết bị"); }
}