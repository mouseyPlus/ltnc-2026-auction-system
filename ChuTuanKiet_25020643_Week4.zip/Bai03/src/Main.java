import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.print("How many workers? ");
        int n = s.nextInt();
        s.nextLine();

        Employee[] emp = new Employee[n];

        for (int i = 0; i < n; i++) {
            String type = s.next().trim();
            String id = s.next().trim();
            String name = s.next().trim();
            double baseSalary = s.nextDouble();

            if (type.equals("O")) {
                emp[i] = new OfficeWorker(id, name, baseSalary);
            } else if (type.equals("T")) {
                double overtimeHours = s.nextDouble();
                emp[i] = new Technician(id, name, baseSalary, overtimeHours);
            }
        }

        double total = 0;
        for (Employee e : emp) {
            System.out.println(e.getName() + " - Pay: " + e.calculatePay());
            e.work();
            total += e.calculatePay();
        }

        System.out.println("TOTAL: " + total);
    }
}

/*
3
O E01 NguyenVanA 5000000
T E02 TranThiB 5000000 30
O E03 LeVanC 4500000
*/