public class Main {
    public static void main(String[] args) {
        (new DataManager()).show();
    }
}