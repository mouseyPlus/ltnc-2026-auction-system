interface IData { void show(); }
// all interfaces are accessed PUBLICLY

class DataManager implements IData {
    public void show() { System.out.println("Show Data"); }
    // attempting to assign weaker access privileges; was public
    // private hep hon public, ma khi implement public interface phai access modifier >= public
    // public rong nhat --> phai dung public khi implement interface
}