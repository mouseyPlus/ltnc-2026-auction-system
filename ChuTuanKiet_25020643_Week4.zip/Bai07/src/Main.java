import java.util.Scanner;
import java.util.Collections;
import java.util.List;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        List<Student> students = new ArrayList<>();

        System.out.print("How many students? ");
        int n = s.nextInt();
        s.nextLine();

        for (int i = 0; i < n; i++) {
            String id = s.next().trim();
            String name = s.next().trim();
            float gpa = s.nextFloat();
            students.add(new Student(id, name, gpa));
        }

        Student.filterLowGpa(students);
        System.out.println("After removing GPA < 5.0:");
        for (Student i : students) {
            System.out.println(i.toString());
        }

        Student.sortByName(students);
        System.out.println("After sorting by Name:");
        for (Student j : students) {
            System.out.println(j);
        }

        Operation<Double> add = (a, b) -> a + b;
        Operation<Double> subtract = (a, b) -> a - b;
        Operation<Double> multiply = (a, b) -> a * b;
        Operation<Double> divide = (a, b) -> a / b;

        double x = 10, y = 15;
        System.out.println("\nx + y = " + add.execute(x, y));
        System.out.println("x - y = " + subtract.execute(x, y));
        System.out.println("x * y = " + multiply.execute(x, y));
        System.out.println("x / y = " + divide.execute(x, y));

        s.close();
    }
}