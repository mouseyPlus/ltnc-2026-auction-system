import java.util.List;

public class Student {
    private String id, name;
    private float gpa;

    public Student(String id, String name, float gpa) {
        this.id = id;
        this.name = name;
        this.gpa = gpa;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public float getGpa() { return gpa; }

    public static void filterLowGpa(List<Student> students) {
        students.removeIf(student -> student.getGpa() < 5.0);
    }

    public static void sortByName(List<Student> students) {
        students.sort((s1, s2) -> s1.getName().compareTo(s2.getName()));
    }

    @Override
    public String toString() {
        return id + " " + name + " " + gpa;
    }
}

@FunctionalInterface
interface Operation<T> {
    T execute(T a, T b);
}