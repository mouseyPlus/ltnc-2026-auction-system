import java.util.ArrayList;
import java.util.List;

abstract class MediaItem {
    protected String id, name;

    public MediaItem(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public abstract String getInfo();
}

class Book extends MediaItem {
    protected String author;
    protected int pages;

    public Book(String id, String name, String author, int pages) {
        super(id, name);
        this.author = author;
        this.pages = pages;
    }

    @Override
    public String getInfo() {
        return name + " - " + author + " - " + pages;
    }
}

class DVD extends MediaItem {
    protected String director;
    protected double duration;

    public DVD(String id, String name, String director, double duration) {
        super(id, name);
        this.director = director;
        this.duration = duration;
    }

    @Override
    public String getInfo() {
        return name + " - " + director + " - " + duration;
    }
}

class LibrarySection<T extends MediaItem> {
    protected List<T> items = new ArrayList<>();

    public void addItem(T item) { items.add(item); }
    public void removeItem(String id) {
        boolean found = false;
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).id.equals(id)) {
                items.remove(i);
                found = true;
                break;
            }
        }
        if (!found) { System.out.println("Can't remove an unexisting file."); }
    }

    public void getDetails() {
        for (T item : items) { System.out.println(item.getInfo()); }
    }
}