import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        System.out.print("How many Media Items? ");
        int n = s.nextInt();
        s.nextLine();

        LibrarySection<Book> books = new LibrarySection<>();
        LibrarySection<DVD> dvds = new LibrarySection<>();

        for (int i = 0; i < n; i++) {
            String[] parts = (s.nextLine()).split(" ", 5);

            String type = parts[0].trim();
            String id = parts[1].trim();
            String name = parts[2].trim();

            if (type.equals("B")) {
                String author = parts[3].trim();
                int pages = Integer.parseInt(parts[4]);
                books.addItem(new Book(id, name, author, pages));
            } else if (type.equals("D")) {
                String director = parts[3].trim();
                double duration = Double.parseDouble(parts[4]);
                dvds.addItem(new DVD(id, name, director, duration));
            }
        }

        System.out.println("Khu vuc sach:");
        books.getDetails();

        System.out.println("Khu vuc DVD:");
        dvds.getDetails();

        s.close();
    }
}