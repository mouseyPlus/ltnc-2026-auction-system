import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.print("How many products? ");
        int n = s.nextInt();
        s.nextLine();

        Warehouse<Food> foods = new Warehouse<>();
        Warehouse<Electronics> electronics = new Warehouse<>();

        for (int i = 0; i < n; i++) {
            String type = s.next().trim();
            String id = s.next().trim();
            String name = s.next().trim();

            if (type.equals("F")) {
                String expiryDate = s.next().trim();
                foods.importItem(new Food(id, name, expiryDate));
            } else if (type.equals("E")) {
                int warrantyMonths = s.nextInt();
                electronics.importItem(new Electronics(id, name, warrantyMonths));
            }
        }

        System.out.println("Kho thuc pham:");
        foods.getDetails();

        System.out.println("\nKho dien tu:");
        electronics.getDetails();

        s.close();
    }
}

//        5
//        F P01 Gao 2026-12-31
//        E P02 Tivi 24
//        F P03 Sua 2026-06-01
//        E P04 TuLanh 36
//        F P05 BanhMi 2026-03-25