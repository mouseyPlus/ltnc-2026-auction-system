import java.util.List;
import java.util.ArrayList;

abstract class Product {
    private String id, name;

    public Product(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public String getId() { return id; }
    public String getName() { return name; }

    public abstract String getInfo();
}

class Food extends Product {
    private String expiryDate;

    public Food(String id, String name, String expiryDate) {
        super(id, name);
        this.expiryDate = expiryDate;
    }

    public String getExpiryDate() { return expiryDate; }

    @Override
    public String getInfo() {
        return getName() + " - " + getExpiryDate();
    }
}

class Electronics extends Product {
    private int warrantyMonths;

    public Electronics(String id, String name, int warrantyMonths) {
        super(id, name);
        this.warrantyMonths = warrantyMonths;
    }

    public int getWarrantyMonths() { return warrantyMonths; }

    @Override
    public String getInfo() {
        return getName() + " - " + getWarrantyMonths() + " thang bao hanh.";
    }
}

class Warehouse<T extends Product> {
    private List<T> items = new ArrayList<>();

    public void importItem(T item) { items.add(item); }
    public void exportItem(String id) {
        boolean found = false;
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).getId().equals(id)) {
                items.remove(i);
                found = true;
                break;
            }
        }
        if (!found) { System.out.println("Item not found!"); }
    }

    public void getDetails() {
        for (T item : items) {
            System.out.println(item.getInfo());
        }
    }
}