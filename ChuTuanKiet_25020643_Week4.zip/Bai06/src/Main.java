import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        Integer[] numbers = {5, 1, 3, 2, 4};
        String[] words = {"Java", "C", "C++", "Python"};
        Student[] students = {
                new Student("Kiet", 3),
                new Student("Kien", 2),
                new Student("Khai", 1)
        };

        ArrayUtils.sort(numbers);
        ArrayUtils.sort(words);
        ArrayUtils.sort(students);

        System.out.println(Arrays.toString(numbers));
        System.out.println(Arrays.toString(words));
        System.out.println(Arrays.toString(students));
    }
}