public class Main {
    public static void main(String[] args) {
        Shape s1 = new Circle(10, 10);
        Shape s2 = new Square(50, 100);

        s1.moveTo(20, 20);
        s2.moveTo(75, 75);
    }
}