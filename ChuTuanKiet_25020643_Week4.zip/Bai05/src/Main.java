public class Main {
    public static void main(String[] args) {
        Pair p1 = new Pair("Tuổi", 20);
        Pair p2 = new Pair("Mã SV", "SV001");
        Pair p3 = new Pair(105, 21.5);

        System.out.println(p1);
        System.out.println(p2);
        System.out.println(p3);
    }
}