import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        System.out.print("How many appliances? ");
        int n = s.nextInt();
        s.nextLine();

        List<Hub> appliances = new ArrayList<>();

        for (int i = 0; i < n; i++) {
            String[] parts = (s.nextLine()).split(" ", 3);

            String type = parts[0].trim();
            int id = Integer.parseInt(parts[1]);
            String name = parts[2].trim();

            switch (type) {
                case "L":
                    appliances.add(new Light(id, name));
                    break;
                case "AC":
                    appliances.add(new AirConditioner(id, name));
                    break;
                case "S":
                    appliances.add(new Speaker(id, name));
                    break;
                case "C":
                    appliances.add(new Curtain(id, name));
                    break;
            }
        }

        System.out.println("Turn off all appliances:");
        for (Hub a : appliances) {
            a.turnOffAll();
        }

        System.out.println("\nSetup Wifi:");
        for (Hub a : appliances) {
            if (a instanceof SetupWifi) {
                ((SetupWifi) a).setupWifi();
            }
        }
        s.close();
    }
}

//            4
//            L 01 LivingRoomLight
//            AC 02 BedroomAC
//            S 03 SmartSpeaker
//            C 04 WindowCurtain