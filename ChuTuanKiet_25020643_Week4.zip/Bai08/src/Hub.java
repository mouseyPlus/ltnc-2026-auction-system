interface SetupWifi { void setupWifi(); }

abstract class Hub {
    protected int id;
    protected String name;
    protected boolean status, wifi;

    public Hub(int id, String name) {
        this.id = id;
        this.name = name;
        this.status = true;
        this.wifi = false;
    }

    public abstract void turnOffAll();
}

class Light extends Hub {
    protected int brightness;
    public Light(int id, String name) {
        super(id, name);
        this.brightness = 50;
    }

    @Override
    public void turnOffAll() {
        System.out.println(name + " turned off.");
        this.status = false;
    }

    public String getBrightness() { return name + " is at Brightness " + brightness + "."; }
    public void setBrightness(int brightness) { this.brightness = brightness; }
}

class AirConditioner extends Hub implements SetupWifi {
    public AirConditioner(int id, String name) {
        super(id, name);
    }

    @Override
    public void turnOffAll() {
        System.out.println(name + " turned off.");
        this.status = false;
    }

    @Override
    public void setupWifi() {
        System.out.println(name + " connected to Wifi.");
        this.wifi = true;
    }
}

class Speaker extends Hub implements SetupWifi {
    protected int volume;
    public Speaker(int id, String name) {
        super(id, name);
        this.volume = 50;
    }

    @Override
    public void turnOffAll() {
        System.out.println(name + " turned off.");
        this.status = false;
    }

    public String getVolume() { return name + " is at Volume " + volume + "."; }
    public void setVolume(int volume) { this.volume = volume; }

    @Override
    public void setupWifi() {
        System.out.println(name + " connected to Wifi.");
        this.wifi = true;
    }
}

class Curtain extends Hub {
    public Curtain(int id, String name) {
        super(id, name);
    }

    @Override
    public void turnOffAll() {
        System.out.println(name + " turned off.");
        this.status = false;
    }
}